import React, { useState } from 'react';
import './dashboard.css';

const Dashboard = () => {
  const [vista, setVista] = useState('crear');

  const renderVista = () => {
    switch (vista) {
      case 'crear':
        return <CrearSolicitud />;
      case 'ver':
        return <VerSolicitudes />;
      default:
        return <Bienvenida />;
    }
  };

  return (
    <div className="dashboard-container">
      <aside className="sidebar">
        <div className="perfil">
          <div className="avatar">👤</div>
          <div className="nombre">Usuario</div>
        </div>
        <nav className="menu">
          <button onClick={() => setVista('crear')}>➕ Crear Solicitud</button>
          <button onClick={() => setVista('ver')}>📄 Ver Solicitudes</button>
        </nav>
      </aside>
      <main className="contenido">
        {renderVista()}
      </main>
    </div>
  );
};

const CrearSolicitud = () => (
  <div>
    <h2>Crear Solicitud</h2>
    <p>Aquí irá el formulario que tú diseñes.</p>
  </div>
);

const VerSolicitudes = () => (
  <div>
    <h2>Ver Solicitudes</h2>
    <p>Aquí se mostrarán las solicitudes registradas.</p>
  </div>
);

const Bienvenida = () => (
  <div>
    <h2>Bienvenido al Dashboard</h2>
  </div>
);

export default Dashboard;
